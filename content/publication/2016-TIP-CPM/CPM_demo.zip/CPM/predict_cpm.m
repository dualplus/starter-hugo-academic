function [label,decV] = predict_cpm(t_data, qss_cls)
% INPUT 
%   t_data:   N by d matrix, N test data
%   qss_cls:  QSS classifier
%       .wt   d+1 vector
% OUTPUT
%   decV      N vector, decision value of t_data by qss_cls
%   label     N vector, {-1 1}
t_data = [t_data, ones(size(t_data,1),1)];
decV   = t_data * qss_cls.wt;
label  = sign(decV);
end
