function models = train_cpm(train_data, test_data, train_y, params)
%% models = train_cpm(train_data, test_data, train_y, test_y, params)
% INPUT:
%    train_data : N by d matrix, N labelled training data
%    test_data  : M by d matrix, M unlabelled test data
%    train_y    : N by 1 vector, {-1 1}
%    params
%         .gamma_I    weight of smoothness item
%         .maxIter    max #iteration of alternating between conf cls and QSSC
%         .threshold  threshold in localized relabel rules
%         .L          smoothness matrix, if not provided, Laplacin will be
%                     used with params.NN = 20(default)
% OUTPUT:
%    models
%         .train    confident classifiers
%             .wp   positive confident classifier
%             .wn   negative confident classifier
%         .test
%             .wt   QSS classifier(test classifier)

% jiabeizeng@buaa.edu.cn
% 2015-10

if ~isfield(params,'gamma_s')             params.gamma_s = 0.08;    end
if ~isfield(params,'gamma_d')             params.gamma_d = 0.08;    end
if ~isfield(params,'gamma_tpn')           params.gamma_tpn = 1e-4;  end
if ~isfield(params,'gamma_t')             params.gamma_t = 0.08;    end
if ~isfield(params,'gamma_I')             params.gamma_I = 0.08;    end
if ~isfield(params,'maxIter')             params.maxIter = 20;      end
if ~isfield(params,'threshold')           params.threshold = 0.14;  end
if ~isfield(params,'NN')                  params.NN = 20;           end
if ~isfield(params,'verbose')             params.verbose = 0;       end
if ~isfield(params,'InitTrModel')         params.InitTrModel = [];  end
if ~isfield(params,'no_test')             params.no_test  = 0;      end
if ~isfield(params,'gamma_test')          params.gamma_test = 1;    end
if ~isfield(params,'num_free')            params.num_free = 0;      end

models = struct('train',[],'test',[]);

train.X =  double([train_data,ones(size(train_data,1),1)]);
test.X  =  double([test_data, ones(size(test_data,1),1)]);

test_n  =  size(test_data,1);

clear train_data test_data;

d = size(train.X,2);

% train a svm 
opt.InitWp    = zeros(d,1);  % Init w_p, confident positive classifer
opt.InitWn    = zeros(d,1);  % Init w_n, confident negative classifer
opt.wt        = zeros(d,1);  % Init w_t, QSS classifier (or test classifier)
opt.gamma_s   = params.gamma_s;
opt.gamma_d   = params.gamma_d;
opt.gamma_tpn = 0;
opt.threshold = params.threshold;
train.Y       = train_y;
train.gtY     = train_y;

%% If there is initialized training model
if ~isempty(params.InitTrModel)
    models.train = params.InitTrModel;
else
    if params.no_test
        opt.threshold = Inf;
    end
    [models.train, obj] = linear_newton(opt,train);
end

topt.InitWt    = zeros(d,1);
topt.gamma_t   = params.gamma_t;
topt.gamma_tpn = params.gamma_tpn;
test.Y         = zeros(test_n, 1);

%% if params.no_test is true, we only train conf cls (dual cls), or
%% we iterate between updating conf cls and QSS cls

if ~ params.no_test
    topt.gamma_I = params.gamma_I;
    if ~isfield(params,'L')
        % if params.L is not given, we calculated L as Laplacian matrix
        lopt =make_options('NN',params.NN);
        lopt.LaplacianNormalize=0;
        test.L = laplacian(lopt,test.X(:,1:d-1));
    else
        test.L = params.L;
    end
end

prev_wt = zeros(d,1);

prev_test_obj  = Inf;
prev_train_obj = Inf;

 if ~params.no_test
     trD = train.X;
 end
 tr_num = size(train.X,1);
for t = 1:params.maxIter
    if params.no_test && t<= params.num_free
        opt.threshold = Inf;
    elseif params.no_test && t == params.num_free + 1;
        opt.threshold = params.threshold;
    end
        
    opt.gamma_tpn = params.gamma_tpn;
    opt.InitWp = models.train.wp;
    opt.InitWn = models.train.wn;
    
    dec_p = train.X(1:tr_num,:) * models.train.wp;
    dec_n = train.X(1:tr_num,:) * models.train.wn;
    
    pl_p = sign(dec_p);
    pl_n = sign(dec_n);
    confuse_idx = pl_p ~= train_y | pl_n ~= train_y;
    
    % updata train.X, train.Y
    if ~params.no_test && t> 1
        % the most confident pts in test_data
        dec_t = test.X * models.test.wt;
        add_idx = (dec_t > 0 & test.Y == 1) | ...
            (dec_t < 0 & test.Y == -1);
        predL = sign(dec_t);
        train.X = [trD; test.X(add_idx,:)];
        train.Y = [train_y; predL(add_idx)*params.gamma_test];
        train.gtY = train.Y;
        train.Y(confuse_idx) = 0;
    else
        train.Y = train_y;
        train.Y(confuse_idx) = 0;
        train.gtY = train_y;
    end
          
    %====confident classifiers=====%%
    [models.train, train_obj]= linear_newton(opt,train);
    
    if ~params.no_test
        topt.wp = models.train.wp;
        topt.wn = models.train.wn;
        topt.InitWt = prev_wt;
        
        dec_p = test.X * models.train.wp;
        dec_n = test.X * models.train.wn;
        
        pl_p = sign(dec_p);
        pl_n = sign(dec_n);
        
        test.Y = zeros(test_n, 1);
        test.Y(pl_p == 1 & pl_n == 1) = 1;
        test.Y(pl_p == -1 & pl_n == -1) = -1;
        
        if sum(test.Y == 1) == 0 || sum(test.Y == -1)==0
            test.Y = (dec_p + dec_n)/2;
            min_y = min(test.Y);
            max_y = max(test.Y);
            test.Y(test.Y >= 0.2 * max_y) = 1;
            test.Y(test.Y <= 0.2 * min_y) = -1;
            test.Y(test.Y ~= 1 & test.Y ~= -1) = 0;
        end
        
        %== QSS classifier == %
        [models.test,test_obj] = linear_newton_3rdc(topt,test);
        
        opt.wt = models.test.wt;
    else
        test_obj = prev_test_obj;
    end
    
     prev_wt = opt.wt;

      if abs(prev_test_obj - test_obj) < 1e-5 &&...
             abs(prev_train_obj - train_obj) < 1e-5
         break;
      end
      prev_test_obj = test_obj;
      prev_train_obj = train_obj;
end


end