% READ ME
% This is a demo of cpm on toy data
% In toy data, the training and test are with different distributions.
% Also, only spatial smoothness is considered in this demo
% 
% When using for AU detection 
% two more functions may be needed (can be found in folder \src)
%    L = comptSTL(data, label,  N)
%        Given a video(some of its frames may be invalid), compute the spatial-tempal smoothness matrix L
%    threshold = computThreshold(train_data, train_y)
%        Compute threshold in localized relabelling rules
% 
% Jiabei Zeng
% 2015-10
% Please e-mail jiabeizeng@buaa.edu.cn or zjb1990@gmail.com if any questions or bugs

clear all;
addpath('src');
addpath('src/Lap');
%% generate toy data
num = 500;
mu = [0  0]; SIGMA = diag( [3 3] ); pts_1 = mvnrnd(mu,SIGMA,num); 
y_1 = ones(num,1);
mu = [4  0]; SIGMA = diag( [3 3] ); pts_2 = mvnrnd(mu,SIGMA,num); 
y_2 = -ones(num,1);

data = [pts_1; pts_2];
y = [y_1; y_2];

clear pts_1 pts_2 y_1 y_2;
num = 100;
mu = [1  5]; SIGMA = diag( [1 1] ); pts_1 = mvnrnd(mu,SIGMA,num); 
y_1 = ones(num,1);
mu = [5  5]; SIGMA = diag( [1 1] ); pts_2 = mvnrnd(mu,SIGMA,num); 
y_2 = -ones(num,1);
test_data = [pts_1; pts_2];
test_y = [y_1; y_2];
clear pts_1 pts_2 y_1 y_2;
h = figure;
plot(data(y == 1,1),data(y == 1,2),...
    'Color','r','Marker','*','LineStyle','none','MarkerSize',2);hold on;
plot(data(y == -1,1),data(y == -1,2),...
    'Color','b','Marker','*','LineStyle','none','MarkerSize',2);hold on;
plot(test_data(test_y == 1,1),test_data(test_y == 1,2),...
    'Color','g','Marker','s','LineStyle','none','MarkerSize',2);hold on;
plot(test_data(test_y == -1,1),test_data(test_y == -1,2),...
    'Color','k','Marker','s','LineStyle','none','MarkerSize',2);hold on;
% end generating toy data
%}

%% Train CPM
params = [];
models = train_cpm(data, test_data, y, params);

%% prediction on test data
[predL, decV]   = predict_cpm(test_data, models.test);
fprintf('accuracy fo test data: %.2f%%\n', sum(predL == test_y)/length(test_y)*100);

%% plot classifiers
xmin = min(data(:,1));
xmax = max(data(:,1));
ymin = min(data(:,2));
ymax = max(data(:,2));
plot_w(h,models.train.wp,[xmin, xmax, ymin, ymax],struct('color',[1 0 0], 'linewidth',2,'linestyle', '-'));
plot_w(h,models.train.wn,[xmin, xmax, ymin, ymax],struct('color',[0 0 1], 'linewidth',2,'linestyle', '-'));
xmin = min(test_data(:,1));
xmax = max(test_data(:,1));
ymin = min(test_data(:,2));
ymax = max(test_data(:,2));
plot_w(h,models.test.wt,[xmin, xmax, ymin, ymax],struct('color',[0 1 0], 'linewidth',2,'linestyle', '-'));
legend('positive train', 'nagetive train', 'positive test', 'nagative test',...
    'conf positive cls','conf negative cls','QSS cls', 4);