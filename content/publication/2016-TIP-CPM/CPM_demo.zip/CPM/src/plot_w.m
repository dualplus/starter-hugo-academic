function hw = plot_w(h,w,range,opt)
% plot classifier w in figure h
% INPUT:
%   h     handle of figure
%   w     classifier
%   range [xmin, xmax,ymin, ymax];
%   opt
%      .color
%      .linewidth
%      .linestyle

xmin = range(1);
xmax = range(2);
ymin = range(3);
ymax = range(4);

x = xmin:(xmax - xmin)/100000:xmax;
y = (-w(1).*x-w(3))/w(2);
idx = y >= ymin & y <= ymax;
x = x(idx);
y = y(idx);
%set(gca,'layer','bottom');
hw = plot(x,y,...
    'Color',opt.color,'LineWidth',opt.linewidth, 'LineStyle',opt.linestyle);hold on;
end