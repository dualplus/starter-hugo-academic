function [classifier,obj] = linear_newton_3rdc(options,data)
% data.X N by d matrix
% data.Y N by 1 vector

% jiabeizeng@buaa.edu.cn
% 2015-10

n=length(data.Y);

% initializing option structure with default values
if ~isfield(options,'Verbose'),           options.Verbose=1; end
if ~isfield(options,'MaxIter'),           options.MaxIter=200; end
if ~isfield(options,'gamma_I'),           options.gamma_I = 0; end
if ~isfield(options,'InitWt'),             options.InitWt=[]; end


% initial [w_p,w_n] vector
if length(options.InitWt)>1
    wt = options.InitWt;
else
    wt = zeros(size(data.X,2) + 1,1);
end



[wt,t,sec,lsiters,obj]=newton(options,data,wt);
        
classifier.wt = wt;

function [wt,t,sec,lsiters,obj]=newton(options,data,wt)
% {newton} trains the classifier using the Newton's method.

tic
[n,d] = size(data.X);
n=length(data.Y);
labeled = data.Y ~= 0;
l_num = nnz(labeled);

gamma_t = options.gamma_t;
gamma_tpn = options.gamma_tpn;
gamma_I = options.gamma_I;
% initial seeding
XWt = double(data.X * wt);


t=0;
lr=1;
sv = false(n,1);

if nargout>4, lsiters=zeros(options.MaxIter,1); end
pre_obj = Inf;
step_t = zeros(d,1);
rep_c = 0;
obj_unchange = 0;
while 1  
    
    sv_prev = sv;     
    
    hloss = sparse([],[],[],n,1,l_num);
    hloss(labeled) = 1- data.Y(labeled).*XWt(labeled);    
    sv = hloss > 0;
    nsv = nnz(sv);
    
    if options.Verbose
         obj = sum(hloss(sv).^2)+...
             gamma_t * wt'*wt + ...
             gamma_tpn * (wt - options.wn)'*(wt - options.wn)+ ...
             gamma_tpn * (wt - options.wp)'*(wt - options.wp) + ...
             gamma_I * (XWt' * data.L)*XWt;
       
        fprintf('[t=%d] obj=%f nev=%d lr=%.4f\n', [t full(obj) nsv lr]);
    end

    % goal conditions
    if t>=options.MaxIter, break, end
    if rep_c > 2, 
        wt = pre_wt;
        obj = pre_obj;
        break; 
    end
    if pre_obj < obj || obj_unchange > 2 
        rep_c = rep_c + 1;
        lr = lr/2; 
        wt = pre_wt + lr * step_t;
        obj_unchange = 0;
        continue;
    elseif abs(pre_obj-obj) < 1e-5
        obj_unchange = obj_unchange + 1;
    else
        obj_unchange = 0;
    end

    rep_c = 0;
    if isequal(sv_prev,sv) ...
            && pre_obj - obj < 1e-5, break, end 
    pre_obj = obj;
    t=t+1;
        

    if gamma_I == 0
        H = [ double(data.X(sv,:)' * data.X(sv,:)) + (gamma_t + 2*gamma_tpn)* speye(d)];
        Y = [(data.Y(sv)'*data.X(sv,:))' + gamma_tpn* options.wp + gamma_tpn * options.wn];
        
        wt_new = H\double(Y);
    else
        H = [ double(data.X(sv,:)' * data.X(sv,:)) + (gamma_t + 2*gamma_tpn)* speye(d) + (double(data.X)' * data.L)*double(data.X)];
        Y = [ (data.Y(sv)'*data.X(sv,:))' + gamma_tpn* options.wp + gamma_tpn * options.wn];
        
        wt_new = H\double(Y);
    end
    
    step_t = wt_new - wt;
    
    pre_wt = wt;
    wt = wt + lr*step_t;
    lsiters(t)=0;
    XWt = double(data.X * wt);
end

if nargout>4, lsiters=lsiters(1:t); end
sec=toc;



