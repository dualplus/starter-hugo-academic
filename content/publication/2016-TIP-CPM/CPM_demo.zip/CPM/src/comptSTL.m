function L = comptSTL(data, label,  N)
% Given a video(some of its frames may be invalid), compute the
% spatial-tempal smoothness matrix L
% INPUT:
%    data:  N by d matrix, N valid data
%    label: (N+I) vector in {-1,0,1}.
%           I is #invalid data, which is with label 0.
%    N:     the gaussian window size will be 2*N+1

% jiabeizeng@buaa.edu.cn
% 2015-10

fprintf('computing L...');
win_value = gausswin(2*N+1);
win_value = win_value(1:N);
win_value = win_value/sum(win_value)/2;

frm_num = length(label);
idx = find(label ~= 0);
y = label(idx);
W = eye(frm_num);
for j = 1:N
    W = W - diag( win_value(N-j+1)*ones(frm_num-j,1), -j);
    W = W - diag( win_value(N-j+1)*ones(frm_num-j,1), j);
end
W = W(idx,idx);

D = pdist_cmu('sqeuclidean', data);
D = -D.*sign(W);
%keyboard;
pos_dis_mat = pdist_cmu('sqeuclidean',data(y == 1,:));
pos_radii   = mean(pos_dis_mat(:));
             
D(D > pos_radii*1.5) = 0;
D = D + eye(size(D,1));
D = sign(D);
W = W.*D;
for i = 1:size(W,1)
    W(i,i) = -(sum(W(:,i)) - W(i,i));
end
% keyboard;
L= sparse(double(W'*W));
end