function threshold = computThreshold(train_data, train_y)
% threshold = computThreshold(train_data, train_y)
% compute threshold in localized relabelling rules
% INPUT:
%    train_data    N by d matrix
%    train_y       N vector
% OUTPUT
%    threshold     double value

% jiabeizeng@buaa.edu.cn
% 2015-10

p_idx = find(train_y == 1);
n_idx = find(train_y == -1);
rpn = 1.9;%length(p_idx)/length(n_idx)*3
if length(p_idx)/length(n_idx) > rpn
    temp = p_idx;
    p_idx = n_idx;
    n_idx = temp;
end
M = pdist_cmu('sqeuclidean',train_data(p_idx,:), train_data);
idx_mat = -ones(size(M));
idx_mat(:, p_idx) = 1;
t_max = mean(M(:));
t_min = 0;
% find t_max and t_min
while 1
    %keyboard;
    tM = (M <= t_max);
    tM = tM.*idx_mat;
    p_num = sum(sum(tM == 1));
    n_num = sum(sum(tM == -1));
    if n_num == 0
        t_max = t_max*2;
        t_min = t_max;
        continue;
    end
    
    if p_num/n_num > rpn
        t_min = t_max;
        t_max = t_max * 2;
        continue;
    end
    
    if abs(p_num/n_num - rpn)/rpn < 1e-3
        threshold = t_max;
        return;
    end
    
    break;
end

t = t_max;

while  1
    tM = (M <= t);
    tM = tM.*idx_mat;
    p_num = sum(sum(tM == 1));
    n_num = sum(sum(tM == -1));
    if n_num == 0, error('n_num == 0!\n'); end
    rpn0 = p_num/n_num;
    if rpn0 > rpn*(1 + 1e-3)
        t_min = t;
    elseif rpn0 < rpn*(1 + 1e-3)
        t_max = t;
    else
        threshold = t;
        return;
    end
    
    t = (t_max + t_min)/2;
    
    if t_max - t_min < 1e-5
        threshold = t;
        return;
    end
end

end