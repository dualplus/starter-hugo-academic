function [classifier, obj] = linear_newton(options,data)

% jiabeizeng@buaa.edu.cn
% 2015-10

% data.X N by d matrix
% data.Y N by 1 vector

n=length(data.Y);


% nn=nnz(data.Y==-1);
% if nn==0, oc=1; else oc=0; end

% initializing option structure with default values
if ~isfield(options,'Verbose'),           options.Verbose=1; end
if ~isfield(options,'MaxIter'),           options.MaxIter=200; end
if ~isfield(options,'InitWp'),             options.InitWp=[]; end
if ~isfield(options,'InitWn'),             options.InitWn=[]; end
if ~isfield(options,'gamma_tpn'),          options.gamma_tpn = 0; end


% initial [w_p,w_n] vector
if length(options.InitWp)>1
    wp=options.InitWp;
else
    error('wp is not initialized!...');
end

if length(options.InitWn)>1
    wn=options.InitWn;
else
    error('wn is not initialized!...');
end

if options.gamma_tpn ~= 0 & ~isfield(options,'wt')
    error('option.wt not exist.');
end

[wp,wn,t,sec,lsiters,obj]=newton(options,data,wp,wn);
        
classifier.wp = wp;
classifier.wn = wn;
% 

function [wp,wn,t,sec,lsiters,obj]=newton(options,data,wp,wn)
tic
[N,d] = size(data.X);
n=length(data.Y);
confused=data.Y==0;

gamma_s = options.gamma_s;
gamma_d = options.gamma_d;
gamma_tpn = options.gamma_tpn;

% initial seeding
XWp = double(data.X * wp);
XWn = double(data.X * wn);


t=0;

sv_p = false(n,1);
sv_n = false(n,1);
y_p = data.Y;
y_n = data.Y;
y_p(confused) = 1;
y_n(confused) = -1;

if isfield(data,'pos_beta')
    beta_p = zeros(size(data.pos_beta));
    beta_n = beta_p;
    beta_p(y_p == 1) = data.pos_beta(y_p == 1);
    beta_p(y_p == -1) = data.neg_beta(y_p == -1);
    
    beta_n(y_n == 1) = data.pos_beta(y_n == 1);
    beta_n(y_n == -1) = data.neg_beta(y_n == -1);
    weight_p_data = data.X;
    weight_n_data = data.X;
    tic;
    for i = 1:length(beta_n)
        weight_p_data(i,:) = weight_p_data(i,:)*beta_p(i);
        weight_n_data(i,:) = weight_n_data(i,:)*beta_n(i);
    end
    toc;
end

%noise
if isfield(options,'threshold')
    for noise = 1:1
        n_idx = find(confused==1 & data.gtY == -1);
        p_idx = find(confused==1 & data.gtY == 1);
        
        % NN noise
        if options.threshold < Inf
            disM = pdist_cmu('sqeuclidean',data.X(p_idx,:), data.X(n_idx,:));
            pos2neg_nn = min(disM,[],2);
            neg2pos_nn = min(disM,[],1);
            n_idx = n_idx(neg2pos_nn > options.threshold);
            p_idx = p_idx(pos2neg_nn > options.threshold);
            y_p(n_idx) = -1;
            y_n(p_idx) = 1;
        end
    end
end

lr = 1;
if nargout>4, lsiters=zeros(options.MaxIter,1); end
pre_obj = Inf;
step_p = zeros(d,1);
step_n = zeros(d,1);
rep_c = 0;
obj_unchange = 0;
while 1  
    
    sv_p_prev = sv_p;
    sv_n_prev = sv_n;        
    
    hloss_p = sparse([],[],[],n,1,n);
    hloss_p = 1- y_p.*XWp;    
    sv_p = hloss_p > 0;
    nsv_p = nnz(sv_p);
    
    hloss_n = sparse([],[],[],n,1,n);
    hloss_n = 1- y_n.*XWn;    
    sv_n = hloss_n > 0;
    nsv_n = nnz(sv_n);
   

    if options.Verbose
        if isfield(data,'pos_beta')
            obj = sum(beta_p(sv_p).*hloss_p(sv_p).^2) + sum(beta_n(sv_n).*hloss_n(sv_n).^2) +...
                gamma_s * wp'*wp + gamma_s * wn'*wn + ...
                gamma_d * (wp-wn)'*(wp-wn) + ...
                gamma_tpn * (wp-options.wt)'*(wp-options.wt) + ...
                gamma_tpn * (wn-options.wt)'*(wn-options.wt);
        else
            obj = sum(hloss_p(sv_p).^2) + sum(hloss_n(sv_n).^2) +...
            gamma_s * wp'*wp + gamma_s * wn'*wn + ...
            gamma_d * (wp-wn)'*(wp-wn) + ...
            gamma_tpn * (wp-options.wt)'*(wp-options.wt) + ...
            gamma_tpn * (wn-options.wt)'*(wn-options.wt);
        end
        fprintf('[t=%d] obj=%f nev_p=%d nev_n=%d lr=%.4f\n', [t full(obj) nsv_p nsv_n lr]);
    end

    % goal conditions
    if t>=options.MaxIter, break; end 
    if rep_c > 2, 
        wp = pre_wp;
        wn = pre_wn;
        obj = pre_obj;
        break; 
    end
    if pre_obj < obj || obj_unchange > 2 
        rep_c = rep_c + 1;
        lr = lr/2; 
        wp = pre_wp + lr * step_p;
        wn = pre_wn + lr * step_n;
        obj_unchange = 0;
        continue;
    elseif abs(pre_obj-obj) < 1e-5
        obj_unchange = obj_unchange + 1;
    else
        obj_unchange = 0;
    end

    rep_c = 0;
    if isequal(sv_p_prev,sv_p) ...
            && isequal(sv_n_prev,sv_n)...
            && pre_obj - obj < 1e-3...
            && pre_obj - obj >= 0, break; end 
   
    pre_obj = obj;
    t=t+1;
        
    % computing new alphas 
    if gamma_tpn ~= 0
        if isfield(data,'pos_beta')
            H = [data.X(sv_p,:)' * weight_p_data(sv_p,:)+ (gamma_s+gamma_d + gamma_tpn)* speye(d),...
                -(gamma_d)*speye(d);...
                -(gamma_d)*speye(d),...
                double(data.X(sv_n,:)'* weight_n_data(sv_n,:)) + (gamma_s+gamma_d + gamma_tpn)* speye(d)];
            Y = [((beta_p(sv_p) .* y_p(sv_p))'*data.X(sv_p,:))' + gamma_tpn * options.wt; ((beta_n(sv_n) .* y_n(sv_n))'*data.X(sv_n,:))' + gamma_tpn * options.wt];
        else
            H = [data.X(sv_p,:)' * data.X(sv_p,:)+ (gamma_s+gamma_d + gamma_tpn)* speye(d),...
                -(gamma_d)*speye(d);...
                -(gamma_d)*speye(d),...
                double(data.X(sv_n,:)'* data.X(sv_n,:)) + (gamma_s+gamma_d + gamma_tpn)* speye(d)];
            Y = [(y_p(sv_p)'*data.X(sv_p,:))' + gamma_tpn * options.wt; (y_n(sv_n)'*data.X(sv_n,:))' + gamma_tpn * options.wt];
        end
        w_p_n = H\double(Y);
    else
        if isfield(data,'pos_beta')
            H = [double(data.X(sv_p,:)' *  weight_p_data(sv_p,:)) + (gamma_s+gamma_d)* speye(d),...
                -gamma_d*speye(d);...
                -gamma_d*speye(d),...
                double(data.X(sv_n,:)' * weight_n_data(sv_n,:)) + (gamma_s+gamma_d)* speye(d)];
            Y = [((beta_p(sv_p) .* y_p(sv_p))'*data.X(sv_p,:))'; ((beta_n(sv_n) .* y_n(sv_n))'*data.X(sv_n,:))'];
        else
            H = [double(data.X(sv_p,:)' *  data.X(sv_p,:)) + (gamma_s+gamma_d)* speye(d),...
                -gamma_d*speye(d);...
                -gamma_d*speye(d),...
                double(data.X(sv_n,:)' * data.X(sv_n,:)) + (gamma_s+gamma_d)* speye(d)];
            Y = [(y_p(sv_p)'*data.X(sv_p,:))'; (y_n(sv_n)'*data.X(sv_n,:))'];
        end
        w_p_n = H\double(Y);
    end
    
    wp_new = w_p_n(1:d);
    wn_new = w_p_n(d+1:2*d);
          

    step_p = wp_new - wp;
    step_n = wn_new - wn;
    
    pre_wp = wp;
    pre_wn = wn;
    
    wp = wp + lr * step_p;
    wn = wn + lr * step_n;
    lsiters(t)=0;
    XWp = double(data.X * wp);
    XWn = double(data.X * wn);
end

if nargout>4, lsiters=lsiters(1:t); end
sec=toc;



