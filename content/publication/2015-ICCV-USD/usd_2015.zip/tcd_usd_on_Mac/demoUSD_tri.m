clear all; close all; addpaths; 

for i = 1%:100 % setting i as 1~100 to ensure that for any case USD find the global optimum

% Genenrate example
% Notice that L has to be set as (the length of target - 1) <- IMPORTANT
pickEx = 7; % pickEx=1~8 for #examples
[s1, s2, s3, B, L, T, nRes, gt] = getExampleTri(pickEx); 

%[s1, s2, B, L, T, nRes, gt] =  getPairs();
%[s1, s2, B, L, T, nRes, gt] =  getToy();
%plot(s1,'b'); hold on; plot(s2,'r'); hold on;

%% Get init indices using k-means
[S1, S2, S3] = initSoftTri(s1, s2, s3, B); % note that the len(S1)=len(s1)+1

%% downsample 1/3
% gap = 3;
% S1 = S1(:,1:gap:end);
% S2 = S2(:,1:gap:end);
% gt = ceil(gt/gap);
% L = round(L/gap);
% T = round(T/gap);

% One may use the hard assignment by [S1, S2] = initHard(s1,s2,B); 
% However be aware that the results are expected to be unsatisfactory.

%% Setup options
opt.dist      = 'l1'; % distance metric ('l1','l2','int');
opt.maxIter   = 1e6;  % max iteration for TCD
opt.nRes      = nRes; % max number of discoveries
opt.isVerbose = 0;    % verbose or not

%% Run TCD
tic
[R,info] = usd_tri(S1, S2, S3, [],[],[], L, T, opt);
toc

%% Print result
%printResult(S1, S2, R, gt);

end