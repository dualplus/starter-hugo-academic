function info = parseLog(filename)
%filename = 'log150309.txt';
fid = fopen(filename);
tline = fgets(fid);
flag = 0;
bid = 0;
while flag < 2
    c =  firstChar(tline);
    if(c == '#')
        bid = bid + 1;
        info(bid) = parseLine(tline);
        tline = fgets(fid);
        if flag == 0 flag = flag + 1; end
    else
        tline = fgets(fid);
        if flag == 1 flag = flag +1; end
    end
end
fclose(fid);

end

function c = firstChar(tline)
for i = 1:length(tline)
    if tline(i) == ' ' | tline(i) == '\t' | tline(i) == '\n'
        c = tline(i);
        continue;
    else
        c = tline(i);
        return;
    end
end
end

function lb = parseLine(tline)
bidx = 1;
eidx = 1;
for i = 1:length(tline)
    if tline(i) == '='
        bidx = i+1;
    end
        
    if bidx > 1 & (tline(i) == '\t' | tline(i) == ' ' | tline(i) == '\n')
        eidx = i-1;
        break;
    end
        
end
lb = str2num(tline(bidx:eidx));

end