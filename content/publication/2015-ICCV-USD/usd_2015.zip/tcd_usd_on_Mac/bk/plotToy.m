function plotToy(s1,s2,gt)

% plot
figure;
subplot(2,2,[1 2]);
plot(s1,'Color','b','LineWidth',2); hold on;
plot([gt(1,1):gt(1,2)], s1([gt(1,1):gt(1,2)]), 'Color','r','LineWidth',2); hold on;

end