function overlap = checkROverlap(rlist, nlap)
    % rlist is sorted by bound value....
    % try
    maxi = min(length(rlist), 2*nlap);
    overlap = [];
    for i = 1:maxi
        for j = i+1:maxi
            if max([rlist(i,1),rlist(j,1)]) <= min([rlist(i,2), rlist(j,2)])
                ilap = [min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3)]),...
                        max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4)]), ...
                        min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3)]),...
                        max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4)])];
                overlap = [overlap; ilap];
            end
        end
    end
    
    %% process overlap to make two sequences the same length
%     for i = 1:size(overlap,1)
%         maxlength = max([overlap(i,2) - overlap(i,1), overlap(i,4) - overlap(i,3)]);
%         overlap(i,2) = overlap(i,1) + maxlength;
%         overlap(i,4) = overlap(i,3) + maxlength;
%     end
    
end