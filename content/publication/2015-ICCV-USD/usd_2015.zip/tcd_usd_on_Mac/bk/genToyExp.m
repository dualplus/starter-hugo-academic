function genToyExp(optIdx)




end