function [s1, s2, B, winLen, T, nMaxRes, gt, figTitle, dispOpt] = getToy( option )
% Generate examples for the TCD algorithm
%   + Input
%     - option: an integer selecting which example to use (1)
%
%   + Output
%     - s1: sequence 1
%     - s2: sequence 2
%     - B: #clusters for pre-clustering
%     - winLen: the minimal length set in Eq (1)
%     - T: commonality interval
%     - nMaxRes: #results for TCD to discover
%     - gt: groundtruth for evaluation
%     - figTitle: title for short description of each example
%
% Wen-Sheng Chu (wschu@cmu.edu)
% Ref: Unsupervised Temporal Commonality Discovery, ECCV 2012.

% defaults
if ~exist('nMaxRes','var'), nMaxRes=1; end
if ~exist('option','var'),  option=1;  end


len = 1000;
% seq_a, 
x1 = 20; x2 = 100; x3 = 400; x4 = 500; x5 = 750; x6=900;
h1 = 50; h2 = -50; h3 = 50;
s1 = toy(x1,x2,x3,x4,x5,x6,h1,h2,h3,len,-1);

% seq_b
y1 = 15; y2 = 95; y3 = 380; y4 = 450; y5 = 760; y6=840;
h1 = 50; h2 = -50; h3 = 50;
s2 = toy(y1,y2,y3,y4,y5,y6,h1,h2,h3,len,1);

B = 10;
winLen = 79;
T = 20;
nMaxRes =3;
gt(1,:) = [x1,x2,y1,y2];
gt(2,:) = [x3,x4,y3,y4];
gt(3,:) = [x5,x6,y5,y6];

dispOpt = 'l1';
figTitle = 'pair_01';
%% display
fprintf('===============================================\n');
fprintf('+ %s\n',figTitle);
fprintf('===============================================\n');
fprintf('+ Getting example:\n');
fprintf('  + len(s1)=%d, len(s2)=%d\n',size(s1,2),size(s2,2));
fprintf('  + %d commonalities:\n',nMaxRes);
for i = 1:size(gt,1)
  fprintf('    - s1[%3d,%3d], s2[%3d,%3d]\n',gt(i,1:2),gt(i,3:4));
end
end

function seq = toy(x1,x2,x3,x4,x5,x6,h1,h2,h3,l,flag)
seq = zeros(1,l);
alpha = h1*2/(x2-x1);
x = x1:1:(x1+x2)/2;    seq(x1:(x1+x2)/2) = alpha*(x-x1);
x = (x1+x2)/2:1:x2;    seq((x1+x2)/2:x2) = h1-alpha*(x-(x1+x2)/2);
seq(x3:x4) = h2;
x = x5:x6;    seq(x5:x6) = h3*sin((x-x5).*(pi/(x6-x5)));

noise_idx = [1:x1,x2:x3,x4:x5,x6:l];
tmp = min([abs(h1),abs(h2),abs(h3)]);
seq(noise_idx) = tmp/4*rand(1,length(noise_idx))*flag;

end
