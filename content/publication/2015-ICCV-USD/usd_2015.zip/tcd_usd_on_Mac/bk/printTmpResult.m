function printTmpResult(rlist, bd, gt, subseq1,info)
% printf gt
for iGT = 1:size(gt,1)
  curgt = gt(iGT,:);
  fprintf('+ truth(%d):\t[%3d, %3d, %3d, %3d  ]\n',iGT,curgt);
end

% printf find
for iFd = 1:size(rlist)
    curfd = rlist(iFd,:);
    fprintf('- find(%d):\t[%3d, %3d, %3d, %3d ]\t bd = %.10f\t iter = %10d\n',iFd,curfd, bd(iFd),info(iFd));
end

% printf subsequence
fprintf('# split of %d subseqence\n', size(subseq1,1));
for i = 1:size(subseq1,1)
    curseq  = subseq1(i,:);
    fprintf(' = the %d th subsequence: [%3d, %3d]\n', i, curseq);
end

end