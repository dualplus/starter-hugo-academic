function [R,bd,info] = resortRlist(rlist,infos, subSeq1, subSeq2)

nseq = length(rlist);
if nseq ~= size(subSeq1)
    fprintf('length of Rlist is not equal to number of subsquences\n');
end

R = [];
bd = [];
info = [];
for i = 1:nseq
    for j = 1:size(rlist{i},2)
        r = zeros(1,4);
        r(1:2) = rlist{i}(j).lo(1:2) + subSeq1(i,1) - 1;
        r(3:4) = rlist{i}(j).lo(3:4) + subSeq2(i,1) - 1;
        info = [info; infos{i}(j).nIter];
        R = [R; r];
        bd = [bd; rlist{i}(j).lb];
    end
end

% sort R,bd,info by bd ascend
[bd, idx] = sort(bd, 'ascend');
R = R(idx, :);
info = info(idx,:);


end