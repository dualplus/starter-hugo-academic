clear all; close all;
pickEx = 6;

addpaths; 
logfile = 'log150309.txt';
delete(logfile);
diary(logfile);
diary on;

for i = 1%:100
% Genenrate example
% Notice that L has to be set as (the length of target - 1) <- IMPORTANT
%pickEx = 5; % pickEx=1~5 for #examples
[s1, s2, B, L, T, nRes, gt] = getExample(pickEx); 

save('data150309.mat','s1','s2','B','L','T','nRes','gt');
%% Get init indices using k-means
[S1, S2] = initSoft(s1, s2, B); % note that the len(S1)=len(s1)+1

% One may use the hard assignment by [S1, S2] = initHard(s1,s2,B); 
% However be aware that the results are expected to be unsatisfactory.

%% Setup options
opt.dist      = 'l1'; % distance metric ('l1','l2','X2','int');
opt.maxIter   = 1e6;  % max iteration for TCD
opt.nRes      = 3; % max number of discoveries
opt.isVerbose = 1;    % verbose or not

%% Run TCD
tic
[R,info] = usd(S1, S2, L, T, opt);
toc
%% Print result
printResult(S1, S2, R, gt)
diary off;

bound = parseLog(logfile);
figure;
plot(bound,'color','b','LineWidth',2); hold on; grid on;
set(gca,'xlim',[1,length(bound)],'ylim',[-2.5,.3]); box on;
end

