clear all; close all; addpaths; 

for i = 1:100
% Genenrate example
% Notice that L has to be set as (the length of target - 1) <- IMPORTANT
pickEx = 1; % pickEx=1~8 for #examples
[s1, s2, B, L, T, nRes, gt] = getExample(pickEx); 
%save('debugdata_ex0.mat','s1', 's2', 'B', 'L', 'T', 'nRes', 'gt');
%load 'debugdata_ex0.mat';


%% Get init indices using k-means
[S1, S2] = initSoft(s1, s2, B); % note that the len(S1)=len(s1)+1

% One may use the hard assignment by [S1, S2] = initHard(s1,s2,B); 
% However be aware that the results are expected to be unsatisfactory.

%% Setup options
opt.dist      = 'l1'; % distance metric ('l1','l2','X2','int');
opt.maxIter   = 1e6;  % max iteration for TCD
opt.nRes      = nRes; % max number of discoveries
opt.isVerbose = 1;    % verbose or not

%% Run TCD
tic
[R,info] = usd(S1, S2, L, T, opt);
toc

%% Print result
rtn = printResult(S1, S2, R, gt);
if rtn ~= 1
    s1
    s2
    keyboard;
end
end