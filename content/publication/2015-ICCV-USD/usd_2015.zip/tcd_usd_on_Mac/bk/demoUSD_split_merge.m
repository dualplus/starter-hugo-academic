clear all; close all; addpaths; 

for i = 1%:100
% Genenrate example
% Notice that L has to be set as (the length of target - 1) <- IMPORTANT
pickEx = 5; % pickEx=1~8 for #examples
[s1, s2, B, L, T, nRes, gt] = getExample(pickEx); 

[S1, S2] = initSoft(s1, s2, B); % note that the len(S1)=len(s1)+1

% split S1,S2
nSeq = 8;
subSeq1 = splitSeq(S1,nSeq,T);
subSeq2 = splitSeq(S2,nSeq,T);

%% Setup options
opt.dist      = 'inner'; % distance metric ('l1','l2','X2','int','kl','inner');
opt.maxIter   = 2e6;  % max iteration for TCD
opt.nRes      = nRes; % max number of discoveries
opt.isVerbose = 0;    % verbose or not

tRlist = cell(nSeq,1);
info = cell(nSeq,1);
parfor i = 1:nSeq
    [tRlist{i},info{i}] = usd(S1(:,subSeq1(i,1):subSeq1(i,2)),S2(:,subSeq2(i,1):subSeq2(i,2)),L,T,opt);   
end


% Rlist
[Rlist,bd,info] = resortRlist(tRlist, info,subSeq1, subSeq2);
printTmpResult(Rlist,bd,gt,subSeq1,info);

%% check overlap of Rlist
Roverlap = checkROverlap(Rlist,2);

newR = cell(size(Roverlap,1),1);
newinfo = cell(size(Roverlap,1),1);
nRlist = zeros(size(Roverlap,1),4);
opt.nRes = 1;
for i = 1:size(Roverlap,1)
    fprintf('search in [%d, %d, %d, %d].\n', Roverlap(i,:));
    [newR{i}, newinfo{i}] = usd(S1(:,Roverlap(i,1):Roverlap(i,2)), S2(:, Roverlap(i,3):Roverlap(i,4)),L,T,opt);
    nRlist(i,1:2) = newR{i}.lo(1:2) + Roverlap(i,1);
    nRlist(i,3:4) = newR{i}.lo(3:4) + Roverlap(i,3);
    fprintf('new R [%d, %d, %d, %d], bd = %.10f, iter = %8d\n',...
        nRlist(i,:), newR{i}.lb, newinfo{i}.nIter);
end

return

%% Get init indices using k-means


% One may use the hard assignment by [S1, S2] = initHard(s1,s2,B); 
% However be aware that the results are expected to be unsatisfactory.



%% Run TCD
% tic
% [R,info] = usd(S1, S2, L, T, opt);
% toc

%% Print result
printResult(S1, S2, Rlist, gt);
% if rtn ~= 1
%     s1
%     s2
%     keyboard;
% end
end