function [s1, s2, B, winLen, T, nMaxRes, gt, figTitle, dispOpt] = getPairs( option )
% Generate examples for the TCD algorithm
%   + Input
%     - option: an integer selecting which example to use (1)
%
%   + Output
%     - s1: sequence 1
%     - s2: sequence 2
%     - B: #clusters for pre-clustering
%     - winLen: the minimal length set in Eq (1)
%     - T: commonality interval
%     - nMaxRes: #results for TCD to discover
%     - gt: groundtruth for evaluation
%     - figTitle: title for short description of each example
%
% Wen-Sheng Chu (wschu@cmu.edu)
% Ref: Unsupervised Temporal Commonality Discovery, ECCV 2012.

% defaults
if ~exist('nMaxRes','var'), nMaxRes=1; end
if ~exist('option','var'),  option=1;  end


filename = 'pair_01.mat';
load(filename);

s1 = seq_a.X(:,1:200);
s2 = seq_b.X(:,1:200);
B = 30;
winLen = 87;
T = 10;
nMaxRes =1;
gt(1,:) = [1,114,1,99];
%gt(2,:) = [239,410,382,468];
%gt(3,:) = [846, 953, 758, 859];

dispOpt = 'l1';
figTitle = 'pair_01';
%% display
fprintf('===============================================\n');
fprintf('+ %s\n',figTitle);
fprintf('===============================================\n');
fprintf('+ Getting example:\n');
fprintf('  + len(s1)=%d, len(s2)=%d\n',size(s1,2),size(s2,2));
fprintf('  + %d commonalities:\n',nMaxRes);
for i = 1:size(gt,1)
  fprintf('    - s1[%3d,%3d], s2[%3d,%3d]\n',gt(i,1:2),gt(i,3:4));
end
