function addpaths

addpath(genpath('lib'));
addpath('src');