function [s1, s2, B, winLen, T, nMaxRes, gt, invalidseg1, invalidseg2, figTitle, dispOpt] = getExample( option )
% Generate examples for the TCD algorithm
%   + Input
%     - option: an integer selecting which example to use (1)
%
%   + Output
%     - s1: sequence 1
%     - s2: sequence 2
%     - B: #clusters for pre-clustering
%     - winLen: the minimal length set in Eq (1)
%     - T: commonality interval
%     - nMaxRes: #results for TCD to discover
%     - gt: groundtruth for evaluation
%     - figTitle: title for short description of each example
%
% Wen-Sheng Chu (wschu@cmu.edu)
% Ref: Unsupervised Temporal Commonality Discovery, ECCV 2012.

% defaults
if ~exist('nMaxRes','var'), nMaxRes=1; end
if ~exist('option','var'),  option=1;  end

dispOpt = 'l1';
switch option
  case 1
    figTitle = 'Ex1: a short and simple demo';
    s1 = floor(rand(1, 15)*15)+1; s2 = floor(rand(1, 15)*20)+1;
    target = [1,3,5,4,6,2];
    s1(3:8) = target; s2(5:10) = target;
    winLen = numel(target)-1; B = 5; 
    T = 2;
    gt = [3, 8, 5, 10];
    nMaxRes = size(gt,1);

  case 2
    figTitle = 'Using ex2: another short and simple demo';
    s1 = rand(1, 30); s2 = rand(1, 30)*4; 
    target = rand(1, 20)*10;
    s1(5:5+length(target)-1) = target; s2(8:8+length(target)-1) = target;
    winLen = length(target)-1; B = 5; nMaxRes = 1; T = 3;
    gt = [5, 5+length(target)-1, 8, 8+length(target)-1];
   
  case 3
    figTitle = 'Using ex3: 1 noisy sin vs 1 noisy sin';
    s1 = rand(1, 200); s2 = rand(1, 200)*2; 
    target1 = sin(-pi:0.1:pi)*3+rand(1,length(-pi:0.1:pi)).*1;
    target2 = sin(-pi:0.1:pi)*3+rand(1,length(-pi:0.1:pi)).*1;
    s1(100:100+length(target1)-1) = target1; s2(120:120+length(target2)-1) = target1;
    winLen = length(target1)-1; B = 5; nMaxRes = 1; T = 20;
    gt = [100, 100+length(target1)-1, 120, 120+length(target2)-1];
    
  case 4
    figTitle = 'Using ex4: 2 sin vs 1 sin';
    s1 = rand(1, 200); s2 = rand(1, 180)*2; 
    target = sin(-pi:0.1:pi)*3+rand(1,length(-pi:0.1:pi)).*2; % length = 63
    s1( 21: 21+length(target)-1) = target; 
    s2( 11: 11+length(target)-1) = target;
    s1( 91: 91+length(target)-1) = target;
    s2(101:101+length(target)-1) = target;
    winLen = length(target)-1; B = 5; nMaxRes = 2; T = 10;
    gt(1,:) = [21, 21+length(target)-1,  11,  11+length(target)-1];
    gt(2,:) = [91, 91+length(target)-1, 101, 101+length(target)-1];
    
  case 5
    figTitle =  'Using ex5: [multiple objects] 2 sin + 2 cos';
    rng(1);
    s1 = rand(1, 800)*0.6; 
    rng(2);
    s2 = rand(1, 800)*2; 
    step = 0.15;
    target1 = sin(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    target2 = cos(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    s1(11:11+length(target1)-1)   = target1; 
    s2(31:31+length(target1)-1)   = target1;
    s1(75:75+length(target2)-1) = target2; 
    s2(104:104+length(target2)-1) = target2;
    winLen = length(target1)-1; B = 5; nMaxRes = 2; T = 30;
    gt(1,:) = [11,  11+length(target1)-1,   31,  31+length(target2)-1];
    gt(2,:) = [75,  75+length(target1)-1, 104, 104+length(target2)-1];
    
  case 6
    figTitle = ['exp 6'];
    
    seed = RandStream('mt19937ar','Seed',10);
    target  = [1 1 2 3 5 6 8 6 5 3 2 1 1];
    
    s1 = round(rand(1,80)*max(target)); s2 = round(rand(1,80)*max(target));
    targetA = target(randperm(seed,numel(target)));
    targetB = target(randperm(seed,numel(target)));
    s1(9:21)  = targetA;
    s1(40:52) = targetA;
    s1(60:72) = targetB;
    
    s2(3:15) = targetA;
    s2(45:57) = targetB;
    s2(65:77) = targetB;
    
    winLen = length(targetA)-1;
    B = 5;
    nMaxRes = 2;
    T = 6;
    gt(1,:) = [9,21,3,15];
    gt(2,:) = [60,72,65,77];
    
    %plot
    hf = figure(1); set(hf,'position',[400, 400, 560, 145]);
    subplot(2,2,[1 2]);
    hold on; box off;
    %plot([gt(1,1):gt(1,2)], s1([gt(1,1):gt(1,2)]), '-ro','MarkerFaceColor','r','LineWidth',2); hold on;
    plot([gt(1,1):gt(1,2)], s1([gt(1,1):gt(1,2)]), '-r','LineWidth',3); hold on;
    plot([40:52],s1(40:52),'Color','r','LineWidth',3); hold on;
    %plot([gt(2,1):gt(2,2)], s1([gt(2,1):gt(2,2)]), '-g^','MarkerFaceColor','g','LineWidth',2); hold on;
    plot([gt(2,1):gt(2,2)], s1([gt(2,1):gt(2,2)]), '-g','LineWidth',3); hold on;
    plot(s1,'Color','b','LineWidth',2);
    axis([0.5,length(s1),0.5,max(s1)]);
    
    subplot(2,2,[3 4]);
    hold on; box off;
    %plot([gt(1,3):gt(1,4)], s2([gt(1,3):gt(1,4)]), 'Color','r','LineWidth',2); hold on;
    plot([gt(1,3):gt(1,4)], s2([gt(1,3):gt(1,4)]), '-r','LineWidth',3); hold on;
    plot([45:57],s2(45:57),'Color','g','LineWidth',3); hold on;
    %plot([gt(2,3):gt(2,4)], s2([gt(2,3):gt(2,4)]), 'Color','g','LineWidth',2); hold on; 
    plot([gt(2,3):gt(2,4)], s2([gt(2,3):gt(2,4)]), '-g','LineWidth',3); hold on; 
    plot(s2,'Color','b','LineWidth',2);
    axis([0.5,length(s2),0.5,max(s2)]);
  case 8
    figTitle =  'Using ex8: [multiple objects] 2 sin + 2 cos';
    rng(1);
    s1 = rand(1, 400)*0.6; 
    rng(2);
    s2 = rand(1, 400)*2; 
    step = 0.15;
    target1 = sin(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    target2 = cos(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    s1(11:11+length(target1)-1)   = target1; 
    s2(31:31+length(target1)-1)   = target1;
    s1(75:75+length(target2)-1) = target2; 
    s2(104:104+length(target2)-1) = target2;
    winLen = length(target1)-1; B = 5; nMaxRes = 2; T = 30;
    gt(1,:) = [11,  11+length(target1)-1,   31,  31+length(target2)-1];
    gt(2,:) = [75, 75+length(target1)-1, 104, 104+length(target2)-1];
    
    invalidseg1 = uint16([50, 60; 150, 200])';
    invalidseg2 = uint16([80 95])';
    
   case 9 
    figTitle =  ['Using ex9: [2 sequences, multiple synchonies] 2 sin + 2 cos',...
        'For parallel debugging.'];
    rng(1);
    s1 = rand(1, 300)*0.6; 
    rng(2);
    s2 = rand(1, 300)*2; 
    step = 0.15;
    target1 = sin(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    target2 = cos(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    
    b11 = 11; b21 = 31;
    b12 = 75; b22 = 104;
    
    s1(b11:b11+length(target1)-1)   = target1; 
    s2(b21:b21+length(target1)-1)   = target1;
    
    s1(b12:b12+length(target2)-1) = target2; 
    s2(b22:b22+length(target2)-1) = target2;
    
    winLen = length(target1)-1; B = 5; nMaxRes = 2; T = 30;
    gt(1,:) = [b11, b11+length(target1)-1,  b21, b21+length(target2)-1];
    gt(2,:) = [b12, b12+length(target1)-1,  b22, b22+length(target2)-1];
    
    
  otherwise
    error('selectExample: option out of range\n');
end

%% display
fprintf('===============================================\n');
fprintf('+ %s\n',figTitle);
fprintf('===============================================\n');
fprintf('+ Getting example:\n');
fprintf('  + len(s1)=%d, len(s2)=%d\n',length(s1),length(s2));
fprintf('  + %d commonalities:\n',nMaxRes);
for i = 1:size(gt,1)
  fprintf('    - s1[%3d,%3d], s2[%3d,%3d]\n',gt(i,1:2),gt(i,3:4));
end
