function [R,bd,info] = resortRlist(rlist,infos)
% [R,bd,info] = resortRlist(rlist,infos, subSeq1, subSeq2)
% INPUT:
%      rlist: nParal by 1 Array of usd result
%         rlist{i}.lo = [b1,e1,b2,e2];
%         rlist{i}.hi = [b1,e1,b2,e2];
%         rlist{i}.lb
%      infos: nParal by 1 Array of usd result
%         infos{i}.nIter = [niter1; niter2;  ...] nRes by 1
% OUTPUT:
%      R:    n by 4 matrix, R(i,:) is a rectangle
%      bd:   n by 1 vector, distance corresponding to R
%      info: iteration_number list correponding to R
%
% zjb1990@gmail.com 
% April 8, 2015
nseq = length(rlist);

R = [];
bd = [];
info = [];
for i = 1:nseq
    for j = 1:size(rlist{i},2)
        info = [info; infos{i}(j).nIter];
        R = [R; rlist{i}(j).lo];
        bd = [bd; rlist{i}(j).lb];
    end
end

% sort R,bd,info by bd ascend
[bd, idx] = sort(bd, 'ascend');
R = R(idx, :);
info = info(idx,:);


end