function [s1, s2, s3, B, winLen, T, nMaxRes, gt, figTitle, dispOpt] = getExampleTri( option )
% Generate examples for the TCD algorithm
%   + Input
%     - option: an integer selecting which example to use (1)
%
%   + Output
%     - s1: sequence 1
%     - s2: sequence 2
%     - B: #clusters for pre-clustering
%     - winLen: the minimal length set in Eq (1)
%     - T: commonality interval
%     - nMaxRes: #results for TCD to discover
%     - gt: groundtruth for evaluation
%     - figTitle: title for short description of each example
%
% Wen-Sheng Chu (wschu@cmu.edu)
% Ref: Unsupervised Temporal Commonality Discovery, ECCV 2012.

% defaults
if ~exist('nMaxRes','var'), nMaxRes=1; end
if ~exist('option','var'),  option=1;  end

dispOpt = 'l1';
switch option
  case 7
    figTitle =  'Using ex7: [multiple objects] 2 sin + 2 cos';
    rng(1);
    s1 = rand(1, 400)*0.6; 
    rng(2);
    s2 = rand(1, 400)*2; 
    rng(3);
    s3 = rand(1, 400)* 3.5;
    step = 0.15;
    target1 = sin(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    target2 = cos(-pi:step:pi)*3+rand(1,length(-pi:step:pi)).*0.2;
    s1(11:11+length(target1)-1)   = target1; 
    s2(31:31+length(target1)-1)   = target1;
    s3(21:21+length(target1)-1)   = target1;
    s1(101:101+length(target2)-1) = target2; 
    s2(131:131+length(target2)-1) = target2;
    s3(116:116+length(target2)-1) = target2;
    winLen = length(target1)-1; B = 5; nMaxRes = 2; T = 30;
    gt(1,:) = [11,  11+length(target1)-1,   31,  31+length(target1)-1, 21, 21+length(target1)-1];
    gt(2,:) = [101, 101+length(target2)-1, 131, 131+length(target2)-1, 116, 116+length(target2)-1];
  otherwise
    error('selectExample: option out of range\n');
end

%% display
fprintf('===============================================\n');
fprintf('+ %s\n',figTitle);
fprintf('===============================================\n');
fprintf('+ Getting example:\n');
fprintf('  + len(s1)=%d, len(s2)=%d, len(s3)=%d.\n',length(s1),length(s2),length(s3));
fprintf('  + %d commonalities:\n',nMaxRes);
for i = 1:size(gt,1)
  fprintf('    - s1[%3d,%3d], s2[%3d,%3d], s3[%3d,%3d]\n',gt(i,1:2),gt(i,3:4), gt(i,5:6));
end
