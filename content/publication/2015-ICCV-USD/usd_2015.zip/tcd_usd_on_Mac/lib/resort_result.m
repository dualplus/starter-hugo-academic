function [Rs, lbs, iters] = resort_result(preRs, prelbs, preiters)
% [Rs, lbs, iters] = resort_result(preRs, prelbs, preiters)

[lbs, idx] = sort(prelbs,'ascend');
Rs = preRs(idx,:);
iters = preiters(idx,:);
end