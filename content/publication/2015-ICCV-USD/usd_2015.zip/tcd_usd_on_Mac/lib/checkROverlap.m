function [overlap, non_lap_idx] = checkROverlap(rlist)
%  overlap = checkROverlap(rlist, nlap)
% INPUT:
%     rlist: n by 4 or m by 6 matrix, each row is a rectangle
%            rlist is sorted by bound value
%     nlap : number of overlap
% OUTPUT
%     overlap: m by 4, or m by 6 overlaps
%     non_lap_idx : idx of rlist that have no overlaps
%
% zjb1990@gmail.com 
% April 8, 2015

maxi = size(rlist,1);
non_lap_idx = ones(maxi, 1);
overlap = [];

nSyn = size(rlist,2)/2;

for i = 1:maxi
    for j = i+1:maxi
        switch nSyn
            case 2
                if max([rlist(i,1),rlist(j,1)]) <= min([rlist(i,2), rlist(j,2)])||...
                   max([rlist(i,3),rlist(j,3)]) <= min([rlist(i,4), rlist(j,4)])
                    ilap = [min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3)]),...
                        max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4)]), ...
                        min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3)]),...
                        max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4)])];
                    overlap = [overlap; ilap];
                    non_lap_idx(i) = 0;
                    non_lap_idx(j) = 0;
                end
            case 3
                if max([rlist(i,1),rlist(j,1)]) <= min([rlist(i,2), rlist(j,2)])||...
                   max([rlist(i,3),rlist(j,3)]) <= min([rlist(i,4), rlist(j,4)])||...
                   max([rlist(i,5),rlist(j,5)]) <= min([rlist(i,6), rlist(j,6)])
                    ilap = [min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3), rlist(j,5), rlist(j,5)]),...
                            max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4), rlist(j,6), rlist(j,6)]),...
                            min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3), rlist(j,5), rlist(j,5)]),...
                            max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4), rlist(j,6), rlist(j,6)]),...
                            min([rlist(i,1), rlist(j,1), rlist(i,3), rlist(j,3), rlist(j,5), rlist(j,5)]),...
                            max([rlist(i,2), rlist(j,2), rlist(i,4), rlist(j,4), rlist(j,6), rlist(j,6)])];
                    overlap = [overlap; ilap];
                    non_lap_idx(i) = 0;
                    non_lap_idx(j) = 0;
                end
        end
    end
end
non_lap_idx = logical(non_lap_idx);
%% process overlap to make two sequences the same length
%     for i = 1:size(overlap,1)
%         maxlength = max([overlap(i,2) - overlap(i,1), overlap(i,4) - overlap(i,3)]);
%         overlap(i,2) = overlap(i,1) + maxlength;
%         overlap(i,4) = overlap(i,3) + maxlength;
%     end
    
end