function [output, paral_info] = usd_parallel_tri(S1, S2, S3, invalid1, invalid2, invalid3, option)
% input
%    S1, S2, invalid1, invalid2

L = option.L;
T = option.T;
nParal = option.nParal;
nRes = option.nRes;
dist = option.dist;
maxIter = option.maxIter;

if ~isfield(option,'isVerbose') isVerbose = 0; else isVerbose = option.isVerbose; end

%% split sequences
subSeq1 = splitSeq(S1,nParal,T+L);
subSeq2 = splitSeq(S2,nParal,T+L);
subSeq3 = splitSeq(S3,nParal,T+L);

%% Setup options
opt.dist      = dist;         % distance metric ('l1','l2','X2','int');
opt.maxIter   = maxIter;      % max iteration for TCD
opt.nRes      = nRes;         % max number of discoveries
opt.isVerbose = isVerbose;    % verbose or not

%% usd over sub-sequence
tRlist = cell(nParal,1);
info = cell(nParal,1);
for i = 1:nParal
    [tRlist{i},info{i}] = usd_tri( S1(:,subSeq1(i,1):subSeq1(i,2)),...
                                   S2(:,subSeq2(i,1):subSeq2(i,2)),...
                                   S3(:,subSeq3(i,1):subSeq3(i,2)),...
                                   int16(invalid1-subSeq1(i,1)+1),...
                                   int16(invalid2-subSeq2(i,1)+1),...
                                   int16(invalid3-subSeq3(i,1)+1),...
                                   L,T,opt);   
end

%% sort the result rectangles by bound-distance value

for i = 1:length(tRlist)
    for j = 1:length(tRlist{i})
        if isempty(tRlist{i}(j).lo)
            tRlist{i} = tRlist{i}(1:j-1);
            info{i} = info{i}(1:j-1);
            break;
        end
        tRlist{i}(j).lo(1:2) = tRlist{i}(j).lo(1:2) + subSeq1(i,1)-1;
        tRlist{i}(j).lo(3:4) = tRlist{i}(j).lo(3:4) + subSeq2(i,1)-1;
        tRlist{i}(j).lo(5:6) = tRlist{i}(j).lo(5:6) + subSeq3(i,1)-1;
        
        tRlist{i}(j).hi(1:2) = tRlist{i}(j).hi(1:2) + subSeq1(i,1)-1;
        tRlist{i}(j).hi(3:4) = tRlist{i}(j).hi(3:4) + subSeq2(i,1)-1;
        tRlist{i}(j).hi(5:6) = tRlist{i}(j).hi(5:6) + subSeq3(i,1)-1;
    end
end
[Rlist,bd,num_iter] = resortRlist(tRlist, info);
paral_info.R    = tRlist;
paral_info.iter = info;

%% check overlap of Rlist
[Roverlap,nolap_idx] = checkROverlap(Rlist);

%% usd over overlaps

nRlist = zeros(size(Roverlap,1),4);
bd_overlap = zeros(size(Roverlap,1),1);
num_iter_overlap = zeros(size(Roverlap,1),1);
opt.nRes = 1;
for i = 1:size(Roverlap,1)
    if isVerbose
        fprintf('search in [%d, %d, %d, %d].\n', Roverlap(i,:));
    end
    [newR, newinfo] = usd_tri(S1(:, Roverlap(i,1):Roverlap(i,2)), ...
                              S2(:, Roverlap(i,3):Roverlap(i,4)), ...
                              S3(:, Roverlap(i,5):Roverlap(i,6)), ...
                          int16(invalid1 - double(Roverlap(i,1)) +1),...
                          int16(invalid2 - double(Roverlap(i,3)) +1),...
                          int16(invalid3 - double(Roverlap(i,5)) +1),...
                          L,T,opt);
    nRlist(i,1:2) = newR.lo(1:2) + Roverlap(i,1)-1;
    nRlist(i,3:4) = newR.lo(3:4) + Roverlap(i,3)-1;
    nRlist(i,5:6) = newR.lo(5:6) + Roverlap(i,5)-1;
    bd_overlap(i) = newR.lb;
    num_iter_overlap(i) = newinfo.nIter;
    if isVerbose
        fprintf('new R [%d, %d, %d, %d, %d, %d], bd = %.10f, iter = %8d\n',...
            nRlist(i,:), bd_overlap(i), num_iter_overlap(i));
    end
end

%% resort the result
[Rs, lbs, iters] = resort_result([Rlist(nolap_idx,:); nRlist], ...
    [bd(nolap_idx);bd_overlap],[num_iter(nolap_idx);num_iter_overlap]);

paral_info.overlap_R   = nRlist;
paral_info.overlap_lbs = bd_overlap;
paral_info.overlap_iter = num_iter_overlap;
paral_info.overlaps = Roverlap;

output = cell(nRes, 1);
for i = 1:nRes
    output{i}.R = Rs(i,:);
    output{i}.lb = lbs(i);
    output{i}.nIter = iters(i);
end

end