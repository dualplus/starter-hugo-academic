function subSeqs = splitSeq(s, nSeq, T)
% subSeqs = splitSeq(s, nSeq, T)
% split sequence s into nSeq splits
% INPUT:   s      original sequence
%          nSeq   number of sequence
%          T      length of offset
% OUTPUT:  subSeqs  nSeq by 2 matrix, record of the subseqence's index
%          subSeqs(i,1)  begin idx of i-th sequence
%          subSeqs(i,2)  end   idx of i-th sequence

L = size(s,2);
subSeqs = zeros(nSeq, 2);
halfT = ceil(T/2);
seqL = ceil(L/nSeq);
for i = 1:nSeq
    subSeqs(i,1) = max(1,1 + (i-1)*seqL-halfT);
    subSeqs(i,2) = min(i * seqL + halfT, L);
end
end