clear all; close all; addpaths; 

% Notice that L has to be set as (the length of target - 1) <- IMPORTANT
pickEx = 7; % pickEx=1~8 for #examples
[s1, s2, s3, B, L, T, nRes, gt] = getExampleTri(pickEx); 

[S1, S2, S3] = initSoftTri(s1, s2, s3, B); % note that the len(S1)=len(s1)+1

% split S1,S2
nParal = 3;
nRes   = 2;
opt.isVerbose = 1;
opt.L = L;
opt.T = T;
opt.nParal = nParal;
opt.nRes = nRes;
opt.dist = 'l1';
opt.maxIter = 1e6;
opt.isVerbose = 0;
[result,paral_info] = usd_parallel_tri(S1, S2, S3,[], [],[],opt);


%% Print result
fprintf('\n ============FINAL RESULTS==============\n');
for i = 1:nRes
    fprintf('The %i-th synchronies: [%d,%d,%d,%d,%d,%d]; lb = %.5e; nIter = %d.\n',...
        i, result{i}.R, result{i}.lb, result{i}.nIter);
end

fprintf('\n ------Parallel iterations-------\n');
for i = 1:nParal
    fprintf('%d-th thread:\n',i);
    for j = 1:length(paral_info.R{i})
        fprintf('synchrony %d: [%5d,%5d,%5d,%5d,%5d,%5d]; lb %.5e; nIter = %d.\n',...
            j, paral_info.R{i}(j).lo, paral_info.R{i}(j).lb, paral_info.iter{i}(j).nIter);
    end
end

fprintf('\n-----find overlaps-----\n');
for i = 1:size(paral_info.overlaps,1)
    fprintf('%d-th overlap: [%5d,%5d,%5d,%5d,%5d,%5d].\n',i, paral_info.overlaps(i,:));
    fprintf('synchrony:[%5d,%5d,%5d,%5d,%5d,%5d]; lb %.5e; nIter = %d.\n',...
        paral_info.overlap_R(i,:),...
        paral_info.overlap_lbs(i),...
        paral_info.overlap_iter(i));
end
